from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path("", views.home, name="home"),
    path("ask/", views.ask_question, name="ask_question"),
    path("question/<int:pk>/", views.question_detail, name="question_detail"),
    path('login/',views.login_view,name='login'),
    path("signup/", views.signup, name="signup"),
    path("logout/", views.logout_account,name='logout'),
    path("questions/", views.all_questions, name="all_questions"),
    path("vote/<int:answer_id>/<str:vote_type>/", views.vote_answer, name="vote_answer"),
    path('answer/<int:answer_id>/accept/', views.accept_answer, name='accept_answer'),
    path("tag/<int:tag_id>/", views.questions_by_tag, name="questions_by_tag"),
]