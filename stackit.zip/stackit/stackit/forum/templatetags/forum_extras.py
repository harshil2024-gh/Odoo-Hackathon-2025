from django import template

register = template.Library()

@register.filter
def get_user_vote(answer, user):
    """
    Return the vote type for a user on a given answer.
    1 = upvote, -1 = downvote, None = no vote.
    """
    vote = answer.votes.filter(user=user).first()
    return vote.vote_type if vote else None
