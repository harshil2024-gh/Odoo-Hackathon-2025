from django.db import models
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField

class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.name

class Question(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    tags = models.ManyToManyField(Tag)
    created_at = models.DateTimeField(auto_now_add=True)

class Answer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    content = RichTextField()
    is_accepted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def get_user_vote(self, user):
        vote = self.votes.filter(user=user).first()
        return vote.vote_type if vote else None

    def upvotes_count(self):
        return self.votes.filter(vote_type=1).count()

    def downvotes_count(self):
        return self.votes.filter(vote_type=-1).count()

    def __str__(self):
        return self.content[:50]
    

# models.py
class SimpleUser(models.Model):
    username = models.CharField(max_length=150, unique=True)
    password = models.CharField(max_length=128)  # Store hashed password ideally

    def str(self):
        return self.username
    
class Vote(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    VOTE_CHOICES = (
    (1, 'Upvote'),
    (-1, 'Downvote'),
    )
    vote_type = models.IntegerField(choices=VOTE_CHOICES)
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE, related_name='votes')



      # 1 for upvote, -1 for downvote

    class Meta:
        unique_together = ("answer", "user")



class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    message = models.TextField()
    url = models.URLField(blank=True, null=True)  # link to related content
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Notification for {self.user.username}"

