from django.contrib import admin
from .models import Tag, Question, Answer, SimpleUser  # ✅ include SimpleUser

@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']
    search_fields = ['name']

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'user', 'created_at']
    list_filter = ['created_at', 'tags']
    search_fields = ['title', 'description']
    filter_horizontal = ['tags']

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['id', 'question', 'user', 'is_accepted', 'created_at']
    list_filter = ['is_accepted', 'created_at']
    search_fields = ['content']

@admin.register(SimpleUser)  # ✅ now registered!
class SimpleUserAdmin(admin.ModelAdmin):
    list_display = ['username', 'password']
    search_fields = ['username']