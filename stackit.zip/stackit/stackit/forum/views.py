from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Question, Answer ,Vote,Notification
from .forms import QuestionForm, AnswerForm
from django.contrib.auth.forms import UserCreationForm  
from django.contrib.auth import login,logout
from django.shortcuts import render, redirect
from django.contrib import messages  # Optional: For user feedback
from .models import SimpleUser
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login
from django.urls import reverse
import re

def home(request):
    questions = Question.objects.all().order_by("-created_at")

    unread_count = 0
    notifications = []

    if request.user.is_authenticated:
        # Fetch the latest 5 notifications
        notifications = request.user.notifications.all().order_by('-created_at')[:5]
        # Count unread notifications
        unread_count = request.user.notifications.filter(is_read=False).count()

    return render(request, "forum/home.html", {
        "questions": questions,
        "notifications": notifications,
        "unread_count": unread_count,
    })

@login_required
def ask_question(request):
    form = QuestionForm(request.POST)
    if request.method == "POST" and form.is_valid():
        q = form.save(commit=False)
        q.user = request.user
        q.save()
        return redirect("home")
    return render(request, "forum/ask.html", {"form": form})

def questions_by_tag(request, tag_id):
    tag = get_object_or_404(Tag, pk=tag_id)
    questions = Question.objects.filter(tags=tag).order_by("-created_at")
    return render(request, "forum/questions_by_tag.html", {"tag": tag, "questions": questions})

def question_detail(request, pk):
    question = get_object_or_404(Question, pk=pk)
    answers = Answer.objects.filter(question=question).select_related('user')

    # Handle Answer form submission
    if request.method == "POST":
        if request.user.is_authenticated:
            a_form = AnswerForm(request.POST)
            if a_form.is_valid():
                answer = a_form.save(commit=False)
                answer.user = request.user
                answer.question = question
                answer.save()

                # 🔔 Notify question owner (except the one answering themselves)
                if question.user != request.user:
                    Notification.objects.create(
                        user=question.user,
                        message=f"{request.user.username} answered your question: {question.title}",
                        url=reverse('question_detail', args=[question.pk])
                    )

                # 🔔 Notify mentioned users using @username
                mentioned_usernames = set(re.findall(r'@(\w+)', answer.content))
                for username in mentioned_usernames:
                    try:
                        mentioned_user = User.objects.get(username=username)
                        if mentioned_user != request.user:
                            Notification.objects.create(
                                user=mentioned_user,
                                message=f"{request.user.username} mentioned you in an answer.",
                                url=reverse('question_detail', args=[question.pk])
                            )
                    except User.DoesNotExist:
                        continue  # Ignore invalid mentions

                return redirect('question_detail', pk=pk)
        else:
            return redirect('login')
    else:
        a_form = AnswerForm()

    # Get vote info
    answer_votes = {}
    if request.user.is_authenticated:
        for answer in answers:
            vote = answer.get_user_vote(request.user)
            answer_votes[answer.id] = vote

    return render(request, 'forum/question_detail.html', {
        'question': question,
        'answers': answers,
        'a_form': a_form,
        'answer_votes': answer_votes,
    })


def signup(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Also store in SimpleUser
            username = form.cleaned_data.get("username")
            raw_password = form.cleaned_data.get("password1")  # password1 is the raw input
            print(username, raw_password)
            # Optionally: hash the password manually (if needed)
            # from django.contrib.auth.hashers import make_password
            # hashed_password = make_password(raw_password)

            # Save to SimpleUser (⚠ This stores password in plain text!)
            SimpleUser.objects.create(
                username=username,
                password=raw_password  # ❗ Not safe for real apps!
            )

            login(request, user)
            messages.success(request, "Signup successful! You are now logged in.")
            return redirect("home")
        else:
            messages.error(request, "Signup failed. Please correct the errors below.")
    else:
        form = UserCreationForm()
    return render(request, "registration/signup.html", {"form": form})

def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}!")
            return redirect("home")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, "registration/login.html", {"form": form})

def logout_account(request):
    logout(request)
    return redirect("home")

def all_questions(request):
    qs = Question.objects.all().order_by("-created_at")
    return render(request, "forum/all_questions.html", {"questions":qs})

@login_required
def vote_answer(request, answer_id, vote_type):
    answer = get_object_or_404(Answer, id=answer_id)

    if vote_type == 'remove':
        Vote.objects.filter(user=request.user, answer=answer).delete()
    else:
        value = 1 if vote_type == 'upvote' else -1
        vote, created = Vote.objects.get_or_create(user=request.user, answer=answer, defaults={'vote_type': value})
        if not created:
            vote.vote_type = value
            vote.save()

    return redirect('question_detail', pk=answer.question.id)


@login_required
def accept_answer(request, answer_id):
    answer = get_object_or_404(Answer, id=answer_id)
    question = answer.question

    # Only the question owner can accept an answer
    if request.user == question.user:
        # Unmark all other answers for this question
        Answer.objects.filter(question=question, is_accepted=True).update(is_accepted=False)

        # Mark this one as accepted
        answer.is_accepted = True
        answer.save()

    return redirect('question_detail', pk=question.pk)