from django import forms
from .models import Question, Answer
from ckeditor.widgets import CKEditorWidget
class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ["title", "description", "tags"]
        widgets = {
            "tags": forms.CheckboxSelectMultiple,
            "description": forms.Textarea(attrs={"rows": 6}),
        }

class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ["content"]
        widgets = {"content": CKEditorWidget()}
